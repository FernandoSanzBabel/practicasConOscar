// Implementación del molinillo
class MolinilloImpl implements Molinillo {
    @Override
    public String molerCafe() {
        return "Café molido";
    }
}