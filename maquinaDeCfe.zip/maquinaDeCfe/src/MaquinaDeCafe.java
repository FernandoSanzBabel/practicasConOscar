// Clase principal que gestiona la máquina de café
class MaquinaDeCafe {
    private Molinillo molinillo;
    private DepositoCafe depositoCafe;
    private DispensadorAzucar dispensadorAzucar;
    private DepositoAgua depositoAgua;

    public MaquinaDeCafe(Molinillo molinillo, DepositoCafe depositoCafe, DispensadorAzucar dispensadorAzucar, DepositoAgua depositoAgua) {
        this.molinillo = molinillo;
        this.depositoCafe = depositoCafe;
        this.dispensadorAzucar = dispensadorAzucar;
        this.depositoAgua = depositoAgua;
    }

    public void prepararCafe(int cantidadCafe, int cantidadAgua) {
        String cafeMolido = molinillo.molerCafe();
        int cafeObtenido = depositoCafe.obtenerCafe(cantidadCafe);
        int aguaObtenida = depositoAgua.obtenerAgua(cantidadAgua);
        if(cantidadCafe <= cafeObtenido){
            System.out.println("Café añadido correctamente");
        }
        else{
            System.out.println("No hay café suficiente");
        }
        if(cantidadAgua <= aguaObtenida){
            System.out.println("Agua dispensada correctamente");
        }
        else{
            System.out.println("No hay agua suficiente");
        }
        String azucarDispensado = dispensadorAzucar.dispensar();

        System.out.println("Café preparado con: " + cafeMolido + ", " + cafeObtenido + "g de café " +
                depositoCafe.getTipoCafe() + ", " + aguaObtenida + "ml de agua y " + azucarDispensado + ".");
    }
}