class DepositoAguaImpl implements DepositoAgua {
    private int cantidadActual;

    public DepositoAguaImpl(int cantidadInicial) {
        this.cantidadActual = cantidadInicial;
    }

    @Override
    public int obtenerAgua(int cantidad) {
        if (cantidadActual >= cantidad) {
            cantidadActual -= cantidad;
            return cantidad;
        } else {
            int aguaDisponible = cantidadActual;
            cantidadActual = 0;
            return aguaDisponible;
        }
    }
    @Override
    public boolean limpiarMaquina(int cantidad){
        if (cantidadActual >= cantidad) {
            return true;
        } else {

            return false;
        }
    }

}