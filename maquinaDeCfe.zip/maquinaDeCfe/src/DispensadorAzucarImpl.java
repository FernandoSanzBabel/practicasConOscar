// Implementación del dispensador de azúcar/sacarina
class DispensadorAzucarImpl implements DispensadorAzucar {
    private String tipoEdulcorante;

    public DispensadorAzucarImpl(String tipoEdulcorante) {
        this.tipoEdulcorante = tipoEdulcorante;
    }

    @Override
    public String dispensar() {
        return tipoEdulcorante + " dispensado";
    }
}