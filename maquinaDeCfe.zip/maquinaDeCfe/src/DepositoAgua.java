// Interfaz para gestionar el depósito de agua
interface DepositoAgua {
    int obtenerAgua(int cantidad);

    boolean limpiarMaquina(int cantidad);
}