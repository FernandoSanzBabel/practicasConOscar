// Interfaz para gestionar el depósito de café
interface DepositoCafe {
    int obtenerCafe(int cantidad);
    String getTipoCafe();
}