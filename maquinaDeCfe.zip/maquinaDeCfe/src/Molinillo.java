// Interfaz para gestionar el molinillo
interface Molinillo {
    String molerCafe();
}