//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Molinillo molinillo = new MolinilloImpl();
        DepositoCafe depositoCafe = new DepositoCafeImpl(500, "normal");
        DispensadorAzucar dispensadorAzucar = new DispensadorAzucarImpl("azúcar");
        DepositoAgua depositoAgua = new DepositoAguaImpl(1000);

        DepositoCafe depositoCafe2 = new DepositoCafeImpl(500, "descafeinado");
        DispensadorAzucar dispensadorAzucar2 = new DispensadorAzucarImpl("sacarina");
        DepositoAgua depositoAgua2 = new DepositoAguaImpl(1000);

        MaquinaDeCafe maquinaDeCafe = new MaquinaDeCafe(molinillo, depositoCafe, dispensadorAzucar, depositoAgua);
        maquinaDeCafe.prepararCafe(20, 200);

        maquinaDeCafe = new MaquinaDeCafe(molinillo, depositoCafe2, dispensadorAzucar2, depositoAgua2);
        maquinaDeCafe.prepararCafe(10, 300);

        maquinaDeCafe = new MaquinaDeCafe(molinillo, depositoCafe, dispensadorAzucar2, depositoAgua);
        maquinaDeCafe.prepararCafe(30, 200);
    }
}