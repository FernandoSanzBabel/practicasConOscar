// Implementación del depósito de café
class DepositoCafeImpl implements DepositoCafe {
    private int cantidadActual;
    private String tipoCafe;

    public DepositoCafeImpl(int cantidadInicial, String tipoCafe) {
        this.cantidadActual = cantidadInicial;
        this.tipoCafe = tipoCafe;
    }

    @Override
    public int obtenerCafe(int cantidad) {
        if (cantidadActual >= cantidad) {
            cantidadActual -= cantidad;
            return cantidad;
        } else {
            int cafeDisponible = cantidadActual;
            cantidadActual = 0;
            return cafeDisponible;
        }
    }

    public String getTipoCafe() {
        return tipoCafe;
    }
}
