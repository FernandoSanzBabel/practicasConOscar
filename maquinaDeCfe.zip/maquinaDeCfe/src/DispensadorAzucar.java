interface DispensadorAzucar {
    String dispensar();
}